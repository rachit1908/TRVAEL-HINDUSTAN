from django.apps import AppConfig


class ContactUsConfig(AppConfig):
    name = 'contact_us'
